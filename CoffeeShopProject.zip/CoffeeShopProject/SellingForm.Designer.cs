﻿
namespace CoffeeShopProject
{
    partial class SellingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textId = new System.Windows.Forms.TextBox();
            this.textname = new System.Windows.Forms.TextBox();
            this.textprice = new System.Windows.Forms.TextBox();
            this.textQt = new System.Windows.Forms.TextBox();
            this.addbutton1 = new System.Windows.Forms.Button();
            this.searchcomboBox2 = new System.Windows.Forms.ComboBox();
            this.clearbutton4 = new System.Windows.Forms.Button();
            this.productdataGridView1 = new System.Windows.Forms.DataGridView();
            this.selldataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2order = new System.Windows.Forms.DataGridView();
            this.productId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productQt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelDate = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelamount = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.labelSeller = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.Logoutbtn = new System.Windows.Forms.Button();
            this.buttonclear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.productdataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.selldataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2order)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(469, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 32);
            this.label1.TabIndex = 16;
            this.label1.Text = "Selling";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(82, 107);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 18);
            this.label4.TabIndex = 21;
            this.label4.Text = " Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(61, 146);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 18);
            this.label2.TabIndex = 22;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(44, 224);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 18);
            this.label3.TabIndex = 23;
            this.label3.Text = "Quantity";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(60, 184);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 20);
            this.label6.TabIndex = 24;
            this.label6.Text = "Price";
            // 
            // textId
            // 
            this.textId.Location = new System.Drawing.Point(168, 101);
            this.textId.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textId.Name = "textId";
            this.textId.Size = new System.Drawing.Size(210, 24);
            this.textId.TabIndex = 25;
            // 
            // textname
            // 
            this.textname.Location = new System.Drawing.Point(168, 133);
            this.textname.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(210, 24);
            this.textname.TabIndex = 26;
            // 
            // textprice
            // 
            this.textprice.Location = new System.Drawing.Point(168, 182);
            this.textprice.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textprice.Name = "textprice";
            this.textprice.Size = new System.Drawing.Size(210, 24);
            this.textprice.TabIndex = 27;
            // 
            // textQt
            // 
            this.textQt.Location = new System.Drawing.Point(168, 224);
            this.textQt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textQt.Name = "textQt";
            this.textQt.Size = new System.Drawing.Size(210, 24);
            this.textQt.TabIndex = 28;
            // 
            // addbutton1
            // 
            this.addbutton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.addbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbutton1.Location = new System.Drawing.Point(132, 289);
            this.addbutton1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.addbutton1.Name = "addbutton1";
            this.addbutton1.Size = new System.Drawing.Size(191, 54);
            this.addbutton1.TabIndex = 29;
            this.addbutton1.Text = "Add order";
            this.addbutton1.UseVisualStyleBackColor = false;
            this.addbutton1.Click += new System.EventHandler(this.addbutton1_Click);
            // 
            // searchcomboBox2
            // 
            this.searchcomboBox2.FormattingEnabled = true;
            this.searchcomboBox2.Location = new System.Drawing.Point(25, 363);
            this.searchcomboBox2.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.searchcomboBox2.Name = "searchcomboBox2";
            this.searchcomboBox2.Size = new System.Drawing.Size(264, 26);
            this.searchcomboBox2.TabIndex = 30;
            // 
            // clearbutton4
            // 
            this.clearbutton4.BackColor = System.Drawing.Color.Crimson;
            this.clearbutton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearbutton4.ForeColor = System.Drawing.Color.White;
            this.clearbutton4.Location = new System.Drawing.Point(308, 356);
            this.clearbutton4.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.clearbutton4.Name = "clearbutton4";
            this.clearbutton4.Size = new System.Drawing.Size(154, 37);
            this.clearbutton4.TabIndex = 31;
            this.clearbutton4.Text = "Refresh";
            this.clearbutton4.UseVisualStyleBackColor = false;
            this.clearbutton4.Click += new System.EventHandler(this.clearbutton4_Click);
            // 
            // productdataGridView1
            // 
            this.productdataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.productdataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.productdataGridView1.Location = new System.Drawing.Point(16, 395);
            this.productdataGridView1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.productdataGridView1.Name = "productdataGridView1";
            this.productdataGridView1.RowHeadersWidth = 51;
            this.productdataGridView1.Size = new System.Drawing.Size(488, 241);
            this.productdataGridView1.TabIndex = 32;
            this.productdataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.productdataGridView1_CellContentClick);
            // 
            // selldataGridView1
            // 
            this.selldataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.selldataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.selldataGridView1.Location = new System.Drawing.Point(514, 395);
            this.selldataGridView1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.selldataGridView1.Name = "selldataGridView1";
            this.selldataGridView1.RowHeadersWidth = 51;
            this.selldataGridView1.Size = new System.Drawing.Size(616, 241);
            this.selldataGridView1.TabIndex = 33;
            this.selldataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.selldataGridView1_CellContentClick);
            // 
            // dataGridView2order
            // 
            this.dataGridView2order.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2order.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2order.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productId,
            this.productName,
            this.productPrice,
            this.productQt,
            this.Total});
            this.dataGridView2order.Location = new System.Drawing.Point(436, 89);
            this.dataGridView2order.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.dataGridView2order.Name = "dataGridView2order";
            this.dataGridView2order.RowHeadersWidth = 51;
            this.dataGridView2order.Size = new System.Drawing.Size(693, 196);
            this.dataGridView2order.TabIndex = 34;
            this.dataGridView2order.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // productId
            // 
            this.productId.HeaderText = "productId";
            this.productId.MinimumWidth = 6;
            this.productId.Name = "productId";
            this.productId.Width = 125;
            // 
            // productName
            // 
            this.productName.HeaderText = "productName";
            this.productName.MinimumWidth = 6;
            this.productName.Name = "productName";
            this.productName.Width = 125;
            // 
            // productPrice
            // 
            this.productPrice.HeaderText = "productPrice";
            this.productPrice.MinimumWidth = 6;
            this.productPrice.Name = "productPrice";
            this.productPrice.Width = 125;
            // 
            // productQt
            // 
            this.productQt.HeaderText = "productQt";
            this.productQt.MinimumWidth = 6;
            this.productQt.Name = "productQt";
            this.productQt.Width = 125;
            // 
            // Total
            // 
            this.Total.HeaderText = "total";
            this.Total.MinimumWidth = 6;
            this.Total.Name = "Total";
            this.Total.Width = 125;
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.BackColor = System.Drawing.Color.Black;
            this.labelDate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelDate.Location = new System.Drawing.Point(1291, 58);
            this.labelDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(48, 18);
            this.labelDate.TabIndex = 37;
            this.labelDate.Text = "Date:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Black;
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(595, 375);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 18);
            this.label7.TabIndex = 38;
            this.label7.Text = "Sell List";
            // 
            // labelamount
            // 
            this.labelamount.AutoSize = true;
            this.labelamount.BackColor = System.Drawing.Color.Black;
            this.labelamount.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelamount.Location = new System.Drawing.Point(724, 289);
            this.labelamount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelamount.Name = "labelamount";
            this.labelamount.Size = new System.Drawing.Size(65, 18);
            this.labelamount.TabIndex = 39;
            this.labelamount.Text = "Amount";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Black;
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(1195, 289);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 18);
            this.label9.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Black;
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(1309, 289);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 18);
            this.label10.TabIndex = 41;
            this.label10.Text = "Tk";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Black;
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(804, 363);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 18);
            this.label11.TabIndex = 42;
            this.label11.Text = "Bill Id";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(877, 360);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(210, 24);
            this.textBox4.TabIndex = 43;
            // 
            // labelSeller
            // 
            this.labelSeller.AutoSize = true;
            this.labelSeller.BackColor = System.Drawing.Color.Black;
            this.labelSeller.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelSeller.Location = new System.Drawing.Point(13, 58);
            this.labelSeller.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSeller.Name = "labelSeller";
            this.labelSeller.Size = new System.Drawing.Size(100, 18);
            this.labelSeller.TabIndex = 44;
            this.labelSeller.Text = "Seller Name";
            // 
            // Add
            // 
            this.Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.Location = new System.Drawing.Point(796, 652);
            this.Add.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(96, 54);
            this.Add.TabIndex = 45;
            this.Add.Text = "Add ";
            this.Add.UseVisualStyleBackColor = false;
            this.Add.Click += new System.EventHandler(this.Add_Click_1);
            // 
            // Logoutbtn
            // 
            this.Logoutbtn.Location = new System.Drawing.Point(33, 662);
            this.Logoutbtn.Name = "Logoutbtn";
            this.Logoutbtn.Size = new System.Drawing.Size(113, 36);
            this.Logoutbtn.TabIndex = 46;
            this.Logoutbtn.Text = "Logout";
            this.Logoutbtn.UseVisualStyleBackColor = true;
            this.Logoutbtn.Click += new System.EventHandler(this.Logoutbtn_Click);
            // 
            // buttonclear
            // 
            this.buttonclear.BackColor = System.Drawing.Color.Red;
            this.buttonclear.Location = new System.Drawing.Point(652, 657);
            this.buttonclear.Name = "buttonclear";
            this.buttonclear.Size = new System.Drawing.Size(113, 36);
            this.buttonclear.TabIndex = 47;
            this.buttonclear.Text = "Clear";
            this.buttonclear.UseVisualStyleBackColor = false;
            this.buttonclear.Click += new System.EventHandler(this.buttonclear_Click);
            // 
            // SellingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CoffeeShopProject.Properties.Resources.stunning_view_colorful_patterned_neon_lights_darkness1;
            this.ClientSize = new System.Drawing.Size(1143, 705);
            this.Controls.Add(this.buttonclear);
            this.Controls.Add(this.Logoutbtn);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.labelSeller);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.labelamount);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.dataGridView2order);
            this.Controls.Add(this.selldataGridView1);
            this.Controls.Add(this.productdataGridView1);
            this.Controls.Add(this.clearbutton4);
            this.Controls.Add(this.searchcomboBox2);
            this.Controls.Add(this.addbutton1);
            this.Controls.Add(this.textQt);
            this.Controls.Add(this.textprice);
            this.Controls.Add(this.textname);
            this.Controls.Add(this.textId);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "SellingForm";
            this.Text = "SellingForm";
            this.Load += new System.EventHandler(this.SellingForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.productdataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.selldataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2order)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textId;
        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.TextBox textprice;
        private System.Windows.Forms.TextBox textQt;
        private System.Windows.Forms.Button addbutton1;
        private System.Windows.Forms.ComboBox searchcomboBox2;
        private System.Windows.Forms.Button clearbutton4;
        private System.Windows.Forms.DataGridView productdataGridView1;
        private System.Windows.Forms.DataGridView selldataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2order;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelamount;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label labelSeller;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.DataGridViewTextBoxColumn productId;
        private System.Windows.Forms.DataGridViewTextBoxColumn productName;
        private System.Windows.Forms.DataGridViewTextBoxColumn productPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn productQt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
        private System.Windows.Forms.Button Logoutbtn;
        private System.Windows.Forms.Button buttonclear;
    }
}