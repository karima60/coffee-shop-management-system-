﻿
namespace CoffeeShopProject
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.prIdtextBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.deletebutton3 = new System.Windows.Forms.Button();
            this.updatebutton2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.addbutton1 = new System.Windows.Forms.Button();
            this.textpName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.qttextBox3 = new System.Windows.Forms.TextBox();
            this.categorycomboBox1 = new System.Windows.Forms.ComboBox();
            this.prPricetextBox2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.clearbutton4 = new System.Windows.Forms.Button();
            this.searchcomboBox2 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.productdataGridView1 = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonSelling = new System.Windows.Forms.Button();
            this.Sellersbutton1 = new System.Windows.Forms.Button();
            this.Categorybutton2 = new System.Windows.Forms.Button();
            this.logoutbutton3 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productdataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.BackgroundImage = global::CoffeeShopProject.Properties.Resources.Screenshot_20231219_123141_2_142_;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.prIdtextBox1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.deletebutton3);
            this.groupBox1.Controls.Add(this.updatebutton2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.addbutton1);
            this.groupBox1.Controls.Add(this.textpName);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.qttextBox3);
            this.groupBox1.Controls.Add(this.categorycomboBox1);
            this.groupBox1.Controls.Add(this.prPricetextBox2);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(150, 71);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1169, 187);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            // 
            // prIdtextBox1
            // 
            this.prIdtextBox1.Location = new System.Drawing.Point(11, 86);
            this.prIdtextBox1.Name = "prIdtextBox1";
            this.prIdtextBox1.Size = new System.Drawing.Size(169, 28);
            this.prIdtextBox1.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(7, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 24);
            this.label4.TabIndex = 20;
            this.label4.Text = "Product Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(-1, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 32);
            this.label1.TabIndex = 15;
            this.label1.Text = "Manage  Products:";
            // 
            // deletebutton3
            // 
            this.deletebutton3.BackColor = System.Drawing.Color.Crimson;
            this.deletebutton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deletebutton3.Location = new System.Drawing.Point(637, 126);
            this.deletebutton3.Margin = new System.Windows.Forms.Padding(4);
            this.deletebutton3.Name = "deletebutton3";
            this.deletebutton3.Size = new System.Drawing.Size(139, 48);
            this.deletebutton3.TabIndex = 19;
            this.deletebutton3.Text = "Delete";
            this.deletebutton3.UseVisualStyleBackColor = false;
            this.deletebutton3.Click += new System.EventHandler(this.deletebutton3_Click);
            // 
            // updatebutton2
            // 
            this.updatebutton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.updatebutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatebutton2.Location = new System.Drawing.Point(417, 126);
            this.updatebutton2.Margin = new System.Windows.Forms.Padding(4);
            this.updatebutton2.Name = "updatebutton2";
            this.updatebutton2.Size = new System.Drawing.Size(136, 48);
            this.updatebutton2.TabIndex = 18;
            this.updatebutton2.Text = "Update";
            this.updatebutton2.UseVisualStyleBackColor = false;
            this.updatebutton2.Click += new System.EventHandler(this.updatebutton2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(205, 62);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product Name";
            // 
            // addbutton1
            // 
            this.addbutton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.addbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbutton1.Location = new System.Drawing.Point(188, 126);
            this.addbutton1.Margin = new System.Windows.Forms.Padding(4);
            this.addbutton1.Name = "addbutton1";
            this.addbutton1.Size = new System.Drawing.Size(153, 48);
            this.addbutton1.TabIndex = 17;
            this.addbutton1.Text = "Add";
            this.addbutton1.UseVisualStyleBackColor = false;
            this.addbutton1.Click += new System.EventHandler(this.addbutton1_Click);
            // 
            // textpName
            // 
            this.textpName.Location = new System.Drawing.Point(209, 86);
            this.textpName.Margin = new System.Windows.Forms.Padding(4);
            this.textpName.Name = "textpName";
            this.textpName.Size = new System.Drawing.Size(221, 28);
            this.textpName.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Black;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(454, 59);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Category";
            // 
            // qttextBox3
            // 
            this.qttextBox3.Location = new System.Drawing.Point(998, 89);
            this.qttextBox3.Margin = new System.Windows.Forms.Padding(4);
            this.qttextBox3.Name = "qttextBox3";
            this.qttextBox3.Size = new System.Drawing.Size(185, 28);
            this.qttextBox3.TabIndex = 10;
            // 
            // categorycomboBox1
            // 
            this.categorycomboBox1.FormattingEnabled = true;
            this.categorycomboBox1.Location = new System.Drawing.Point(458, 84);
            this.categorycomboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.categorycomboBox1.Name = "categorycomboBox1";
            this.categorycomboBox1.Size = new System.Drawing.Size(255, 30);
            this.categorycomboBox1.TabIndex = 13;
            // 
            // prPricetextBox2
            // 
            this.prPricetextBox2.Location = new System.Drawing.Point(751, 86);
            this.prPricetextBox2.Margin = new System.Windows.Forms.Padding(4);
            this.prPricetextBox2.Name = "prPricetextBox2";
            this.prPricetextBox2.Size = new System.Drawing.Size(207, 28);
            this.prPricetextBox2.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Black;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(1003, 59);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Quantity";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(747, 59);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Price";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Sienna;
            this.panel2.Controls.Add(this.clearbutton4);
            this.panel2.Controls.Add(this.searchcomboBox2);
            this.panel2.Controls.Add(this.label9);
            this.panel2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.panel2.Location = new System.Drawing.Point(150, 266);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1198, 44);
            this.panel2.TabIndex = 22;
            // 
            // clearbutton4
            // 
            this.clearbutton4.BackColor = System.Drawing.Color.Crimson;
            this.clearbutton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearbutton4.ForeColor = System.Drawing.Color.White;
            this.clearbutton4.Location = new System.Drawing.Point(724, 4);
            this.clearbutton4.Margin = new System.Windows.Forms.Padding(4);
            this.clearbutton4.Name = "clearbutton4";
            this.clearbutton4.Size = new System.Drawing.Size(153, 33);
            this.clearbutton4.TabIndex = 17;
            this.clearbutton4.Text = "Refresh";
            this.clearbutton4.UseVisualStyleBackColor = false;
            this.clearbutton4.Click += new System.EventHandler(this.clearbutton4_Click);
            // 
            // searchcomboBox2
            // 
            this.searchcomboBox2.FormattingEnabled = true;
            this.searchcomboBox2.Location = new System.Drawing.Point(332, 11);
            this.searchcomboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.searchcomboBox2.Name = "searchcomboBox2";
            this.searchcomboBox2.Size = new System.Drawing.Size(305, 24);
            this.searchcomboBox2.TabIndex = 15;
            this.searchcomboBox2.SelectedIndexChanged += new System.EventHandler(this.searchcomboBox2_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(224, 17);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 20);
            this.label9.TabIndex = 16;
            this.label9.Text = "Search:";
            // 
            // productdataGridView1
            // 
            this.productdataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.productdataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.productdataGridView1.Location = new System.Drawing.Point(144, 318);
            this.productdataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.productdataGridView1.Name = "productdataGridView1";
            this.productdataGridView1.RowHeadersWidth = 51;
            this.productdataGridView1.Size = new System.Drawing.Size(1204, 292);
            this.productdataGridView1.TabIndex = 23;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(476, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(191, 36);
            this.label8.TabIndex = 24;
            this.label8.Text = "Coffee Shop";
            // 
            // buttonSelling
            // 
            this.buttonSelling.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSelling.Location = new System.Drawing.Point(21, 130);
            this.buttonSelling.Name = "buttonSelling";
            this.buttonSelling.Size = new System.Drawing.Size(109, 43);
            this.buttonSelling.TabIndex = 26;
            this.buttonSelling.Text = "Selling";
            this.buttonSelling.UseVisualStyleBackColor = true;
            this.buttonSelling.Click += new System.EventHandler(this.buttonSelling_Click);
            // 
            // Sellersbutton1
            // 
            this.Sellersbutton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sellersbutton1.Location = new System.Drawing.Point(21, 210);
            this.Sellersbutton1.Name = "Sellersbutton1";
            this.Sellersbutton1.Size = new System.Drawing.Size(110, 48);
            this.Sellersbutton1.TabIndex = 27;
            this.Sellersbutton1.Text = "Sellers";
            this.Sellersbutton1.UseVisualStyleBackColor = true;
            this.Sellersbutton1.Click += new System.EventHandler(this.Sellersbutton1_Click);
            // 
            // Categorybutton2
            // 
            this.Categorybutton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Categorybutton2.Location = new System.Drawing.Point(21, 299);
            this.Categorybutton2.Name = "Categorybutton2";
            this.Categorybutton2.Size = new System.Drawing.Size(113, 48);
            this.Categorybutton2.TabIndex = 28;
            this.Categorybutton2.Text = "Category";
            this.Categorybutton2.UseVisualStyleBackColor = true;
            this.Categorybutton2.Click += new System.EventHandler(this.Categorybutton2_Click);
            // 
            // logoutbutton3
            // 
            this.logoutbutton3.BackColor = System.Drawing.Color.White;
            this.logoutbutton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutbutton3.Location = new System.Drawing.Point(21, 471);
            this.logoutbutton3.Name = "logoutbutton3";
            this.logoutbutton3.Size = new System.Drawing.Size(116, 49);
            this.logoutbutton3.TabIndex = 29;
            this.logoutbutton3.Text = "Logout";
            this.logoutbutton3.UseVisualStyleBackColor = false;
            this.logoutbutton3.Click += new System.EventHandler(this.logoutbutton3_Click);
            // 
            // ProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1358, 650);
            this.Controls.Add(this.logoutbutton3);
            this.Controls.Add(this.Categorybutton2);
            this.Controls.Add(this.Sellersbutton1);
            this.Controls.Add(this.buttonSelling);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.productdataGridView1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ProductForm";
            this.Text = "ProductForm";
            this.Load += new System.EventHandler(this.ProductForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.productdataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox prIdtextBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button deletebutton3;
        private System.Windows.Forms.Button updatebutton2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button addbutton1;
        private System.Windows.Forms.TextBox textpName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox qttextBox3;
        private System.Windows.Forms.ComboBox categorycomboBox1;
        private System.Windows.Forms.TextBox prPricetextBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button clearbutton4;
        private System.Windows.Forms.ComboBox searchcomboBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView productdataGridView1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonSelling;
        private System.Windows.Forms.Button Sellersbutton1;
        private System.Windows.Forms.Button Categorybutton2;
        private System.Windows.Forms.Button logoutbutton3;
    }
}