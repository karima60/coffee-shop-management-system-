﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CoffeeShopProject
{
    public partial class SellingForm : Form
    {
        DBConnect dBCon = new DBConnect();
        public SellingForm()
        {
            InitializeComponent();
        }
        private void getCategory()
        {
            string selectQuerry = "SELECT * FROM Category";
            SqlCommand command = new SqlCommand(selectQuerry, dBCon.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            searchcomboBox2.DataSource = table;
            searchcomboBox2.ValueMember = "CatName";

        }

        private void getTable()
        {
            string selectQuerry = "SELECT productName, productPrice FROM Product";
            SqlCommand command = new SqlCommand(selectQuerry, dBCon.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            productdataGridView1.DataSource = table;
        }
        private void getSellTable()
        {
            string selectQuerry = "SELECT * FROM Bill";
            SqlCommand command = new SqlCommand(selectQuerry, dBCon.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            selldataGridView1.DataSource = table;
        }

        private void SellingForm_Load(object sender, EventArgs e)
        {

            labelDate.Text = DateTime.Today.ToShortDateString();
            //labelSeller.Text = Form1.Name;
            getTable();
            getCategory();
            getSellTable();
        }

        private void productdataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           // textname.Text = productdataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            //textprice.Text = productdataGridView1.SelectedRows[0].Cells[1].Value.ToString();
        }
        int grandTotal = 0, n = 0;

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void selldataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void addbutton1_Click(object sender, EventArgs e)
        {
            if (textname.Text == "" || textQt.Text == "")
            {
                MessageBox.Show("Missing Information", "Information Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                int Total = Convert.ToInt32(textprice.Text) * Convert.ToInt32(textQt.Text);
                DataGridViewRow addRow = new DataGridViewRow();
                addRow.CreateCells(dataGridView2order);
                addRow.Cells[0].Value = ++n;
                addRow.Cells[1].Value = textname.Text;
                addRow.Cells[2].Value = textprice.Text;
                addRow.Cells[3].Value = textQt.Text;
                addRow.Cells[4].Value = Total;
                dataGridView2order.Rows.Add(addRow);
                grandTotal = grandTotal + Total;
                
                labelamount.Text = " "+grandTotal;
            }
        }

        private void clearbutton4_Click(object sender, EventArgs e)
        {
            getTable();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void Logoutbtn_Click(object sender, EventArgs e)
        {
            Form1 login = new Form1();
            login.Show();
            this.Hide();
        }

        private void buttonclear_Click(object sender, EventArgs e)
        {
            this.textId.Clear();
            //this.labelDate.Clear();
            // this.grandTotal.Clear();//this.clrValue();
        }

        private void Add_Click_1(object sender, EventArgs e)
        {
            try
            {
                string insertQuery = "INSERT INTO Bill VALUES('" + textId.Text +  "','" + labelDate.Text + "','" + grandTotal.ToString() + "')";
                SqlCommand command = new SqlCommand(insertQuery, dBCon.GetCon());
                dBCon.OpenCon();
                command.ExecuteNonQuery();
                MessageBox.Show("Order Added Successfully", "Order Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dBCon.CloseCon();
                getSellTable();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       
    }
}
