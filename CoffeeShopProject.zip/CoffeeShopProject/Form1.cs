﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CoffeeShopProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-2IQUCOQ;Initial Catalog=log;Integrated Security=True");

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Loginbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textuser.Text) || string.IsNullOrEmpty(textpass.Text))
            {
                MessageBox.Show("Please fill in both username and password.");
                return; // Exit the method without further processing
            }
            // string query = "Select Count(*) from login where userId='" + textuser.Text + "' and Password='" + textpass.Text + "'";
            string query = "SELECT Count(*),UserRole FROM log1 WHERE userId='" + textuser.Text + "' AND Password='" + textpass.Text + "' GROUP BY UserRole";

            SqlDataAdapter sda = new SqlDataAdapter(query, con);

            DataTable dt = new DataTable();
            sda.Fill(dt);


            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() == "1")
            //if (dt.Rows[0][0].ToString() == "1")
            {
                //MainForm f2 = new MainForm();
                // this.Hide();
                // f2.Show();

                if (dt.Rows[0]["UserRole"].ToString() == "Admin")

                {
                    MainForm f2 = new MainForm();
                    this.Hide();
                    f2.Show();

                }

                else if (dt.Rows[0]["UserRole"].ToString() == "Seller")
                {
                    SellingForm sell = new SellingForm();
                    sell.Show();
                    this.Hide();
                }

            }
            else
            {
                MessageBox.Show("Invalid User");
            }


            }
        
        

        private void Clearbtn_Click(object sender, EventArgs e)
            {
                this.textuser.Clear();
                this.textpass.Clear();//this.clrValue();
            }

            private void textpass_TextChanged(object sender, EventArgs e)
            {

            }

            private void checkBoxpass_CheckedChanged(object sender, EventArgs e)
            {
                textpass.UseSystemPasswordChar = !checkBoxpass.Checked;
            }



        }
    }



       
    


