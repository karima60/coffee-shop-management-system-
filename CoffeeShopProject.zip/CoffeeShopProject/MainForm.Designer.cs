﻿
namespace CoffeeShopProject
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Productbtn = new System.Windows.Forms.Button();
            this.Categorybtn = new System.Windows.Forms.Button();
            this.Sellingbtn = new System.Windows.Forms.Button();
            this.Sellersbtn = new System.Windows.Forms.Button();
            this.Logoutbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Productbtn
            // 
            this.Productbtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Productbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Productbtn.Location = new System.Drawing.Point(336, 273);
            this.Productbtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Productbtn.Name = "Productbtn";
            this.Productbtn.Size = new System.Drawing.Size(103, 29);
            this.Productbtn.TabIndex = 2;
            this.Productbtn.Text = "Products";
            this.Productbtn.UseVisualStyleBackColor = false;
            this.Productbtn.Click += new System.EventHandler(this.Productbtn_Click);
            // 
            // Categorybtn
            // 
            this.Categorybtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Categorybtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Categorybtn.Location = new System.Drawing.Point(515, 273);
            this.Categorybtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Categorybtn.Name = "Categorybtn";
            this.Categorybtn.Size = new System.Drawing.Size(103, 29);
            this.Categorybtn.TabIndex = 3;
            this.Categorybtn.Text = "Category";
            this.Categorybtn.UseVisualStyleBackColor = false;
            this.Categorybtn.Click += new System.EventHandler(this.Categorybtn_Click);
            // 
            // Sellingbtn
            // 
            this.Sellingbtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Sellingbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sellingbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Sellingbtn.Location = new System.Drawing.Point(65, 282);
            this.Sellingbtn.Margin = new System.Windows.Forms.Padding(4);
            this.Sellingbtn.Name = "Sellingbtn";
            this.Sellingbtn.Size = new System.Drawing.Size(103, 29);
            this.Sellingbtn.TabIndex = 0;
            this.Sellingbtn.Text = "Selling";
            this.Sellingbtn.UseVisualStyleBackColor = false;
            this.Sellingbtn.Click += new System.EventHandler(this.Sellingbtn_Click);
            // 
            // Sellersbtn
            // 
            this.Sellersbtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Sellersbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Sellersbtn.Location = new System.Drawing.Point(265, 454);
            this.Sellersbtn.Margin = new System.Windows.Forms.Padding(4);
            this.Sellersbtn.Name = "Sellersbtn";
            this.Sellersbtn.Size = new System.Drawing.Size(103, 29);
            this.Sellersbtn.TabIndex = 1;
            this.Sellersbtn.Text = "Sellers";
            this.Sellersbtn.UseVisualStyleBackColor = false;
            this.Sellersbtn.Click += new System.EventHandler(this.Sellersbtn_Click);
            // 
            // Logoutbtn
            // 
            this.Logoutbtn.BackColor = System.Drawing.Color.Maroon;
            this.Logoutbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Logoutbtn.Location = new System.Drawing.Point(283, 504);
            this.Logoutbtn.Name = "Logoutbtn";
            this.Logoutbtn.Size = new System.Drawing.Size(75, 34);
            this.Logoutbtn.TabIndex = 4;
            this.Logoutbtn.Text = "Logout";
            this.Logoutbtn.UseVisualStyleBackColor = false;
            this.Logoutbtn.Click += new System.EventHandler(this.Logoutbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(237, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 37);
            this.label1.TabIndex = 7;
            this.label1.Text = "Coffee Shop";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::CoffeeShopProject.Properties.Resources.Screenshot_20231221_101507_2;
            this.pictureBox3.Location = new System.Drawing.Point(244, 378);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(148, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CoffeeShopProject.Properties.Resources.Screenshot_20231219_220642_2;
            this.pictureBox2.Location = new System.Drawing.Point(12, 110);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(268, 142);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CoffeeShopProject.Properties.Resources.Screenshot_20231219_221034_2;
            this.pictureBox1.Location = new System.Drawing.Point(336, 110);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(282, 142);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(675, 550);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Logoutbtn);
            this.Controls.Add(this.Categorybtn);
            this.Controls.Add(this.Productbtn);
            this.Controls.Add(this.Sellersbtn);
            this.Controls.Add(this.Sellingbtn);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainForm";
            this.Text = "MainForm";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Productbtn;
        private System.Windows.Forms.Button Categorybtn;
        private System.Windows.Forms.Button Sellingbtn;
        private System.Windows.Forms.Button Sellersbtn;
        private System.Windows.Forms.Button Logoutbtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}